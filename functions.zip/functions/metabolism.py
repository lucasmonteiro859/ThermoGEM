from reaction import Reaction
from metabolite import Metabolite, H2o
import random
import pandas as pd
from cobra.sampling import sample

class Metabolism:

    def __init__(self, sbmlMdl, rcnTrgs, tmp0 = 298.15, nSims = 100):

        self.sbmlMdl = sbmlMdl
        self.rcnTrgs = rcnTrgs

        self.tmp0 = tmp0
        self.tmp = tmp0
        self.nSims = nSims

        self.sbmlMtbs, self.mtbs = self.initMtbs()
        self.sbmlRcns, self.rcns = self.initRcns()
        self.trgRcns, self.trgMtbs, self.bioMRcn = self.initTrgs()

        self.rcnSbmls = {rcn: sblm for sblm, rcn in self.sbmlRcns.items()}

        self.maxGrw = sbmlMdl.optimize().objective_value # grw (growth) is defined as the flux of the biomass reaction 
        self.h2ocCnc = None

    def initMtbs(self):

        sbmlMtbs = {}
        for sblmMtb in self.sbmlMdl.metabolites:
            if sblmMtb._id == 'h2o_c': sbmlMtbs[sblmMtb] = H2o(self, sblmMtb.name, sblmMtb._id, sblmMtb.compartment)
            else: sbmlMtbs[sblmMtb] = Metabolite(self, sblmMtb.name, sblmMtb._id, sblmMtb.compartment)

        return sbmlMtbs, tuple(sbmlMtbs.values())

    def initTrgMtbs(self):

        return tuple(mtb for mtb in self.mtbs if mtb.getCmp() == 'c' and mtb.getId() != 'h2o_c')

    def initRcns(self):

        sbmlRcns = {}

        for sblmRcn in self.sbmlMdl.reactions: 

            rcts = []
            rctStcs = []
            prts = []
            prtStcs = []
            dct = sblmRcn._metabolites

            for i in dct:
                if dct[i] < 0: 
                    rcts.append(self.sbmlMtbs[i])
                    rctStcs.append(dct[i])
                else:
                    prts.append(self.sbmlMtbs[i])
                    prtStcs.append(dct[i])
            
            sbmlRcns[sblmRcn] = Reaction(self, sblmRcn.name, sblmRcn._id, tuple(rcts), tuple(rctStcs), tuple(prts), tuple(prtStcs), self.rcnTrgs[sblmRcn._id])
        
        return sbmlRcns, tuple(sbmlRcns.values())
    
    def initTrgs(self):
        
        trgRcns = []
        trgMtbs = set()
        bioMRcn = None

        for rcn in self.rcns: 
            if rcn.getTrg() == 'bioMRcn': bioMRcn = rcn
            elif rcn.getTrg(): 
                trgRcns.append(rcn)
                for rct in rcn.getRcts(): trgMtbs.add(rct)
                for prt in rcn.getPrts(): trgMtbs.add(prt)

        return tuple(trgRcns), tuple(trgMtbs), bioMRcn
    
    def setWghs(self, trgRcnWghs):

        for trgRcn in self.trgRcns: trgRcn.setWgh(trgRcnWghs[trgRcn.getId()])

    def setOptFlxInts(self, optFlxInts):

        for trgRcn in self.trgRcns: trgRcn.setOptFlxInt(optFlxInts[trgRcn.getId()])

    def setCncs(self, mtbCncs):

        for trgMtb in self.trgMtbs: trgMtb.setCnc(mtbCncs[trgMtb.getId()])

    def setTrgRcnGec0s(self, trgRcnGec0s):

        for trgRcn in self.trgRcns: trgRcn.setTrgRcnGec0(trgRcnGec0s[trgRcn.getId()])

    def setTrgRcnHgr0s(self, trgRcnHgr0s):

        for trgRcn in self.trgRcns: trgRcn.setTrgRcnHgr0(trgRcnHgr0s[trgRcn.getId()])

    def setTrgRcnGec0Errs(self, trgRcnGec0Errs):

        for trgRcn in self.trgRcns: trgRcn.setTrgRcnGec0Err(trgRcnGec0Errs[trgRcn.getId()])

    def setTrgRcnHgr0Errs(self, trgRcnHgr0Errs):

        for trgRcn in self.trgRcns: trgRcn.setTrgRcnHgr0Err(trgRcnHgr0Errs[trgRcn.getId()])

    def setSimKcs(self, tmp):

        for trgRcn in self.trgRcns: trgRcn.setSimKcs(tmp)

    def setH2ocCnc(self, cnc):

        self.h2ocCnc = cnc

    def setGenFlxs(self):

        for trgRcn in self.trgRcns: trgRcn.setGenFlxs()

    def setSimFlxs(self):

        for trgRcn in self.trgRcns: trgRcn.setSimFlxs()

    def calOptFlxInts(self, optFrc=0.95):

        from cobra.flux_analysis import flux_variability_analysis     

        reactionObjects = [self.rcnSbmls[rcn] for rcn in self.trgRcns]
        solution = flux_variability_analysis(self.sbmlMdl, reactionObjects, fraction_of_optimum = optFrc, loopless=True)
        solution['int'] = list(zip(solution['minimum'], solution['maximum']))
        
        return solution['int'].to_dict()

    def getFlxSmp(self, n): return sample(self.sbmlMdl, n)

    def getTmp0(self): return self.tmp0

    def getTmp(self): return self.tmp

    def genKcs(self, tmp = 298.15):
    
        kcrs = {}
        kcfs = {}
        for trgRcn in self.trgRcns:
            kcr, kcf = trgRcn.genKcs(tmp)
            _id = trgRcn.getId()
            kcrs[_id] = kcr
            kcfs[_id] = kcf

        return kcrs, kcfs

    def genNoise(self, mtns, mtnDv):
        
        simRng = range(1, self.nSims) # para o 1º nunca se alterar
        dvSims = random.sample([i for i in simRng], int(mtns*100)-1)
        
        return [1] + [1+random.uniform(-mtnDv, mtnDv) if i in dvSims else 1 for i in simRng]

    def setSimCncs(self):

        for trgMtb in self.trgMtbs: trgMtb.setSimCncs()

    def nosSimCncs(self, mtns, mtnDv):

        for trgMtb in self.trgMtbs: trgMtb.nosSimCncs(self.genNoise(mtns, mtnDv))

    def nosSimKcs(self, mtns, mtnDv):

        for trgRnc in self.trgRcns: trgRnc.nosSimKcs(self.genNoise(mtns, mtnDv))

    def setSimPrds(self):

        for trgRnc in self.trgRcns: trgRnc.setSimPrds()

    def chgCncs(self, sim):

        for trgMtb in self.trgMtbs: trgMtb.chgCnc(sim)

    def calSimOsm(self, sim):

        return sum([trgMtb.getSimCnc(sim) for trgMtb in self.trgMtbs]) - self.h2ocCnc

    def getMinDstSim(self):

        dsts = [sum([trgRcn.calSqrSimDst(sim) for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
        minDst = min(dsts)
        minDstSim = dsts.index(minDst)
    
        return minDst, minDstSim

    def setSimVars(self, tmp = 298.15):

        self.setSimCncs()
        self.nosSimCncs(mtns = 0.5, mtnDv = 0.1)
        self.setSimPrds()
        self.setGenFlxs()
        self.setSimKcs(tmp)
        self.setSimFlxs()

    def repSimVars(self, sim):

        for trgMtb in self.trgMtbs: 
            trgMtb.repSimCncs(sim)

        for trgRcn in self.trgRcns: 
            trgRcn.repSimKcs(sim)
            trgRcn.repGenFlxs(sim)
            trgRcn.setSimPrds()

    def getSmp(self, n = 100):
        
        return sample(self.sbmlMdl, n)



    def initGenAlg(self):

        self.setSimCncs()
        self.nosSimCncs(mtns = 0.5, mtnDv = 0.1)
        self.setSimPrds()
        
        self.setFlxSgn()
        self.setSimKcs2()
        self.nosSimKcs(mtns = 0.5, mtnDv = 0.1)
        
    def setFlxSgn(self):

        for trgRcn in self.trgRcns: trgRcn.setFlxSgn(self.tmp)

    def setSimKcs2(self): 
        
        for trgRcn in self.trgRcns: trgRcn.setSimKcs2()

    def calSimKcfs(self):

        for trgRcn in self.trgRcns: trgRcn.calSimKcfs()

    def setTmp(self, tmp):

        self.tmp = tmp

    def runGenAlg(self, sample):

        # for _ in range(200):

        #     self.calSimKcfs()
        #     dsts = [sum([(sample[trgRcn._id]-trgRcn.calSimFlx(sim))**2 for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
        #     #print([[selfy.simKcfs[0],selfy.rctPrds[0],selfy.simKcrs[0],selfy.prtPrds[0]] for selfy in self.trgRcns])
        #     minDst = min(dsts)
        #     minDstSim = dsts.index(minDst)
        #     print(minDst)

        #     self.repSimVars(minDstSim)
        #     self.nosSimCncs(mtns = 0.5, mtnDv = 0.4)
        #     self.nosSimKcs(mtns = 0.5, mtnDv = 0.4)

        for _ in range(300):

            self.calSimKcfs()
            # dsts = [sum([(sample[trgRcn._id]-trgRcn.calSimFlx(sim))**2 for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
            
            dsts = [sum([(1-trgRcn.calSimFlx(sim)/sample[trgRcn._id])**2 for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
            # print([[selfy.simKcfs[0],selfy.rctPrds[0],selfy.simKcrs[0],selfy.prtPrds[0]] for selfy in self.trgRcns])
            minDst = min(dsts)
            minDstSim = dsts.index(minDst)
            # print(minDst)

            self.repSimVars(minDstSim)
            self.nosSimCncs(mtns = 0.4, mtnDv = 0.2)
            self.nosSimKcs(mtns = 0.4, mtnDv = 0.2)

        for _ in range(300):

            self.calSimKcfs()
            # dsts = [sum([(sample[trgRcn._id]-trgRcn.calSimFlx(sim))**2 for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
            
            dsts = [sum([(1-trgRcn.calSimFlx(sim)/sample[trgRcn._id])**2 for trgRcn in self.trgRcns])**0.5 for sim in range(self.nSims)]
            # print([[selfy.simKcfs[0],selfy.rctPrds[0],selfy.simKcrs[0],selfy.prtPrds[0]] for selfy in self.trgRcns])
            minDst = min(dsts)
            minDstSim = dsts.index(minDst)
            # print(minDst)

            self.repSimVars(minDstSim)
            self.nosSimCncs(mtns = 0.1, mtnDv = 0.05)
            self.nosSimKcs(mtns = 0.1, mtnDv = 0.05)


        # cncSum = sum([trgMtb.simCncs[minDstSim] for trgMtb in self.trgMtbs])-41000
        # kcrSum = sum([trgRcn.simKcrs[minDstSim] for trgRcn in self.trgRcns])
        # kcfSum = sum([trgRcn.simKcfs[minDstSim] for trgRcn in self.trgRcns])

        simCncs = [trgMtb.simCncs[minDstSim] for trgMtb in self.trgMtbs]
        simKcrs = [trgRcn.simKcrs[minDstSim] for trgRcn in self.trgRcns]
        simKcfs = [trgRcn.simKcfs[minDstSim] for trgRcn in self.trgRcns]

        # sim = sample.iloc[0]
        # print(f'minDst: {minDst}')
        # print(f'cncSum_{sim}: {cncSum}')
        # print(f'kcrSum_{sim}: {kcrSum}')
        # print(f'kcfSum_{sim}: {kcfSum}')
    
        return minDst, simCncs, simKcrs, simKcfs
        
    
    def printSimStt(self, sim):
 
    #    for trgRcn in self.trgRcns: print(f'{trgRcn._id}: {round(trgRcn.simKcrs[sim],2)}, {round(trgRcn.simKcfs[sim],2)}')
    #    for trgMtb in self.trgMtbs: print(f'{trgMtb._id}: {trgMtb.simCncs[sim]}')
       print(f'cncSum_{sim}: {sum([trgMtb.simCncs[sim] for trgMtb in self.trgMtbs])-41000}')
       print(f'kcrSum_{sim}: {sum([trgRcn.simKcrs[sim] for trgRcn in self.trgRcns])}')
       print(f'kcfSum_{sim}: {sum([trgRcn.simKcfs[sim] for trgRcn in self.trgRcns])}')

    def genAlg(self, smp, tmp = None):

        if tmp == None: tmp = self.tmp0

        self.setTmp(tmp)
        self.initGenAlg()
        minDst, simCncs, simKcrs, simKcfs = self.runGenAlg(smp)
        print(smp, tmp, minDst, simCncs, simKcrs, simKcfs)

        return [tmp, minDst, simCncs, simKcrs, simKcfs]























    # def calSimFlx(self, sim):

    #     ids = []
    #     kcrs = []
    #     kcfs = []
    #     rctPrds = []
    #     prtPrds = []
    #     # flx0 = []
    #     for trgRcn in self.trgRcns:
    #         ids.append(trgRcn._id)
    #         kcrs.append(trgRcn.getSimKcr(sim))
    #         kcfs.append(trgRcn.getSimKcf(sim))
    #         rctPrds.append(trgRcn.getSimRctPrd(sim))
    #         prtPrds.append(trgRcn.getSimPrtPrd(sim))
    #         # flx0.append(trgRcn.genOptFlxSmp())

    #     df = pd.DataFrame()
    #     df['ids'] = ids
    #     df.set_index('ids', inplace=True)
    #     df['kcrs'] = kcrs
    #     df['kcfs'] = kcfs
    #     df['rctPrds'] = rctPrds
    #     df['prtPrds'] = prtPrds
    #     df['kcfs*prtPrds'] = df['kcfs']*df['rctPrds']
    #     df['kcrs*rctPrds'] = df['kcrs']*df['prtPrds']
    #     df['flx'] = df['kcfs*prtPrds']-df['kcrs*rctPrds']
    #     # df['flx0'] = flx0
    #     # df['dFlxSqr'] = (df['flx']-df['flx0'])**2

    #     return df['kcfs*prtPrds']-df['kcrs*rctPrds']
