import numpy as np
import random
from other import wghPrd

class Reaction:

    def __init__(self, met, _nm, _id, rcts, rctStcs, prts, prtStcs, trg):
        
        self.met = met        
        self._nm = _nm
        self._id =  _id

        self.rcts = rcts  
        self.rctStcs = rctStcs
        self.prts = prts
        self.prtStcs = prtStcs

        self.trg = trg
        self.keq = None
        self.flxSgn = None # flux signal - none for reversible, -1 for irreversible in reverse direction and 1 for forward

        self.optFlxMin = None
        self.optFlxMax = None
        self.wgh = None

        self.gec0 = None # gibbs free energy change at room temperature
        self.hgr0 = None # enthalpy/gibbs energy ratio at room temperature
        self.gec0Err = None
        self.hgr0Err = None

        self.simKcrs = [None for _ in range(met.nSims)]
        self.simKcfs = [None for _ in range(met.nSims)]
        self.rctPrds = [None for _ in range(met.nSims)]
        self.prtPrds = [None for _ in range(met.nSims)]
        self.genFlxs = [None for _ in range(met.nSims)]
        self.simFlxs = [None for _ in range(met.nSims)]

        self.simFlxMax = None
        self.simFlxMin = None
        # print(self.trg)

    def __str__(self): return self._id

#################################### setters 

    def setWgh(self, wgh): self.wgh = wgh

    def setOptFlxInt(self, optFlxTnt): self.optFlxMin, self.optFlxMax = optFlxTnt[0], optFlxTnt[1]

    def setTrgRcnGec0(self, trgRcnGec0): self.gec0 = trgRcnGec0

    def setTrgRcnHgr0(self, trgRcnHgr0): self.hgr0 = trgRcnHgr0

    def setTrgRcnGec0Err(self, trgRcnGec0Err): self.gec0Err = trgRcnGec0Err

    def setTrgRcnHgr0Err(self, trgRcnHgr0Err): self.hgr0Err = trgRcnHgr0Err

    def setSimKcs(self, tmp): 
        
        for sim in range(self.met.nSims):
            simKcr, simKcf = self.calSimKcs(sim, tmp)
            self.simKcrs[sim] = simKcr
            self.simKcfs[sim] = simKcf

    def setSimPrds(self):
        
        self.rctPrds = [self.calSimRctPrd(sim) for sim in range(self.met.nSims)]
        self.prtPrds = [self.calSimPrtPrd(sim) for sim in range(self.met.nSims)]

    def setGenFlxs(self):

        self.genFlxs = [self.genOptFlx() for _ in range(self.met.nSims)]

    def setSimFlxs(self):

        self.simFlxs = [self.calSimFlx(sim) for sim in range(self.met.nSims)]

#################################### getters 

    def getTrg(self): return self.trg
    
    def getId(self): return self._id

    def getRcts(self): return self.rcts

    def getPrts(self): return self.prts

    def getHgr0(self): return self.hgr0
    # def getSimKcr(self, sim): return self.simKcrs[sim]

    # def getSimKcf(self, sim): return self.simKcfs[sim]

    # def getSimRctPrd(self, sim): return self.rctPrds[sim]

    # def getSimPrtPrd(self, sim): return self.prtPrds[sim]

#################################### calculaters 

    def calGec(self, tmp, errGec0=0, errHgr0=0):

        tmpNrm = tmp/self.met.getTmp0()
        return (self.gec0+errGec0)*((self.hgr0+errHgr0)-(self.hgr0+errHgr0)*tmpNrm+tmpNrm)
    
    def calKeq(self, tmp, errGec0=0, errHgr0=0):

        RT = 8.31446261815324*0.001*tmp
        return np.exp(-self.calGec(tmp, errGec0, errHgr0)/RT)
    
    def calKeqErr(self, tmp):
    
        R = 8.31446261815324*0.001
        tmp0 = self.met.getTmp0()
        dKdG = (self.hgr0/tmp-self.hgr0/tmp0+1/tmp0)*self.gec0Err
        dKdo = self.gec0*(1/tmp0-1/tmp)*self.hgr0Err

        return (dKdG**2+dKdo**2)**0.5

    # def calRctPrd(self):

    #     return wghPrd([mtb.getCnc() for mtb in self.rcts], [abs(stc) for stc in self.rctStcs])

    # def calPrtPrd(self):

    #     return wghPrd([mtb.getCnc() for mtb in self.prts], self.prtStcs)

    def calSimRctPrd(self, sim):

        return wghPrd([mtb.getSimCnc(sim) for mtb in self.rcts], [abs(stc) for stc in self.rctStcs])

    def calSimPrtPrd(self, sim):

        return wghPrd([mtb.getSimCnc(sim) for mtb in self.prts], self.prtStcs)

    def genOptFlx(self):

        return random.uniform(self.optFlxMin, self.optFlxMax)
    
    def calSimKcs(self, sim, tmp):
        
        genFlx = self.genFlxs[sim]
        rctPrd, prtPrd = self.rctPrds[sim], self.prtPrds[sim]
        Keq = self.calKeq(tmp)

        kcr = genFlx/(Keq*rctPrd-prtPrd)
        if Keq < 0.001: kcf = 0
        elif Keq > 1000: 
            kcf = Keq*kcr
            kcr = 0
        else: kcf = Keq*kcr

        return kcr, kcf

    def calSimFlx(self, sim):

        return self.simKcfs[sim]*self.rctPrds[sim]-self.simKcrs[sim]*self.prtPrds[sim]
    
    def calSqrSimDst(self, sim):

        return (self.genFlxs[sim].real-self.simFlxs[sim].real)**2
    
    def repSimKcs(self, sim):

        self.simKcrs = [self.simKcrs[sim] for _ in self.simKcrs]
        self.simKcfs = [self.simKcfs[sim] for _ in self.simKcfs]

    def repSimPrds(self, sim):

        self.rctPrds = [self.rctPrds[sim] for _ in self.rctPrds]
        self.prtPrds = [self.prtPrds[sim] for _ in self.prtPrds]

    def repGenFlxs(self, sim):

        self.genFlxs = [self.genFlxs[sim] for _ in self.genFlxs] 

    def nosSimKcs(self, noise):

        self.simKcrs = [kcr*dv if kcr*dv > 0 else 0 for kcr, dv in zip(self.simKcrs, noise)]
        self.simKcfs = [kcf*dv if kcf*dv > 0 else 0 for kcf, dv in zip(self.simKcfs, noise)]

    def anl(self, value):

        bol = self.simFlxMin <= value <= self.simFlxMax
        return 1-(1-bol)*self.wgh
    
    def setFlxInt(self):

        self.simFlxMin = min(self.simFlxs)
        self.simFlxMax = max(self.simFlxs)


    def testtest(self, tmp, value):

        R = 8.31446261815324*0.001
        f = np.exp((1/R)*(1/298.15-1/tmp)*(self.gec0*self.hgr0+25))
        bol = self.optFlxMin*f <= value <= self.optFlxMax*f

        return 1-(1-bol)*self.wgh


    def setFlxSgn(self, tmp, thr=1000):

        self.keq = self.calKeq(tmp)
        if self.keq > thr: self.flxSgn = 1
        elif self.keq < 1/thr: self.flxSgn = -1

    def setSimKcs2(self): 
        
        if self.flxSgn == -1: 
            self.simKcrs = [1 for _ in range(self.met.nSims)]
            self.simKcfs = [0 for _ in range(self.met.nSims)]
        elif self.flxSgn == 1: 
            self.simKcrs = [0 for _ in range(self.met.nSims)]
            self.simKcfs = [1 for _ in range(self.met.nSims)]
        else:
            self.simKcrs = [1 for _ in range(self.met.nSims)]
            self.simKcfs = [1 for _ in range(self.met.nSims)]

    def calSimKcfs(self):

        if self.flxSgn is None: self.simKcfs = [kcr*self.keq for kcr in self.simKcrs]

