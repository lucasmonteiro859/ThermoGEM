import matplotlib.pyplot as plt
import numpy as np
import os
import json
from scipy.stats import norm 
from matplotlib.ticker import AutoLocator, AutoMinorLocator

def readJson(fldPth, filename):

    with open(f'{fldPth}/{filename}', "r") as j:
        return json.load(j)

def saveJson(my_dict, path):

    if input(f'Save {path}? (y/n)') == 'y': 

        print(f'{path} saved')
        with open(path, "w") as j:
            json.dump(my_dict, j, indent=4)

    else: print('Canceled operation')


def plotMtbGec(met, tmps, mtbNm):

    for obj in met.trgRcns:
        if obj._id == mtbNm: 
            gecs = [obj.calKeq(temp) for temp in tmps]
            errs1 = [obj.calKeq(temp, errGec0=obj.gec0Err, errHgr0=obj.hgr0Err) for temp in tmps]
            errs2 = [obj.calKeq(temp, errGec0=obj.gec0Err, errHgr0=-obj.hgr0Err) for temp in tmps]
            errs3 = [obj.calKeq(temp, errGec0=-obj.gec0Err, errHgr0=obj.hgr0Err) for temp in tmps]
            errs4 = [obj.calKeq(temp, errGec0=-obj.gec0Err, errHgr0=-obj.hgr0Err) for temp in tmps]
            gecLow = [min(errs) for errs in zip(errs1, errs2, errs3, errs4)]
            gecHgh = [max(errs) for errs in zip(errs1, errs2, errs3, errs4)]

    return gecs, gecLow, gecHgh


def plotGecs(met):

    plt.rcParams.update({'font.size': 11})

    fig, axs = plt.subplots(2, 2, figsize=(12,10))
    axs = list(axs.flat)
    print(axs)
    #plt.figure(figsize=(10, 6))
    temperature_range = range(10, 800, 10)


    for obj in met.trgRcns:
        #if obj._id in ['PGM', 'GAPD', 'ACONTb', 'GLUDy', 'ACONTa']:
        #R = 8.31446261815324*0.001
        keqs = [obj.calKeq(temp) for temp in temperature_range] 
        #errs = [obj.calKeqErr(temp) for temp in temperature_range]
        energies = [obj.calGec(temp) for temp in temperature_range]
        #if energies[-1] > 3000: 
        #axs[0].plot(temperature_range, energies, label=f'{obj._id}')#f'{obj._nm},{obj._id},{obj.wgh}')
        if abs(np.log10(keqs[34])-np.log10(keqs[24])) > 20: axs[0].plot(temperature_range, keqs, label=f'{obj._id}')#f'{obj._nm},{obj._id},{obj.wgh}')
        elif abs(np.log10(keqs[1])-np.log10(keqs[-1])) < 2: axs[1].plot(temperature_range, keqs, label=f'{obj._id}')#f'{obj._nm},{obj._id},{obj.wgh}')
        else: 
            if np.log10(keqs[0]) < -5: axs[2].plot(temperature_range, keqs, label=f'{obj._id}')#f'{obj._nm},{obj._id},{obj.wgh}')
            else: axs[3].plot(temperature_range, keqs, label=f'{obj._id}')#f'{obj._nm},{obj._id},{obj.wgh}')

    for i in range(len(axs)):

        # if i == 0:
        #     axs[i].set_xlabel('Temperature (K)')
        #     axs[i].set_ylabel('Standard Gibbs Free Energy (kJ/mol)')
        #     axs[i].set_xlim(-10, 810)
        # else:
        axs[i].set_xlabel('Temperature (K)')
        axs[i].set_ylabel('Equilibrium Constant')
        axs[i].set_yscale('log')
        axs[i].set_ylim(0.0001, 10000)
        axs[i].set_xlim(-10, 810)
            

        ax_ = axs[i].twiny()
        ax_.set_xlabel('Temperature (ºC)') 
        ax_.set_xlim(-283.15, 536.85)

        axs[i].xaxis.set_major_locator(AutoLocator())
        axs[i].xaxis.set_minor_locator(AutoMinorLocator())
        ax_.xaxis.set_major_locator(AutoLocator())
        ax_.xaxis.set_minor_locator(AutoMinorLocator())
        axs[i].xaxis.grid(which='both', linestyle='--', linewidth=0.5)
    
    #axs[1].legend(loc='upper right')#, bbox_to_anchor=(-0.18, -0.12), ncol=9)#fancybox=False, shadow=False
    axs[0].legend(loc='center left', bbox_to_anchor=(1, 0.5))
    axs[1].legend(loc='center left', bbox_to_anchor=(1, 0.5))
    axs[2].legend(loc='center left', bbox_to_anchor=(1, 0.5))
    axs[3].legend(loc='center left', bbox_to_anchor=(1, 0.5))
    fig.tight_layout()

    plt.subplots_adjust(left=0.07, right=0.88, wspace=0.55, hspace=0.3)
    plt.show()



    # nrmGecx1 = []
    # nrmGecy1 = []
    # for i in range(len(gecx1)):
    #     if 0.001 < gecy1[i] < 1000: 
    #         nrmGecx1.append(gecx1[i])
    #         nrmGecy1.append(gecy1[i])
    # print(max(nrmGecy1), min(nrmGecy1))
    # nrmGecx1 = [(i-min(nrmGecx1))/(max(nrmGecx1)-min(nrmGecx1)) for i in nrmGecx1]
    # nrmGecy1 = [(i-min(nrmGecy1))/(max(nrmGecy1)-min(nrmGecy1)) for i in nrmGecy1]

    # nrmGecx2 = []
    # nrmGecy2 = []
    # for i in range(len(gecy2)):
    #     if 0.001 < gecx2[i] < 1000: 
    #         nrmGecx2.append(gecx2[i])
    #         nrmGecy2.append(gecy2[i])
    # nrmGecx2 = [(i-min(nrmGecx2))/(max(nrmGecx2)-min(nrmGecx2)) for i in nrmGecx2]
    # nrmGecy2 = [(i-min(nrmGecy2))/(max(nrmGecy2)-min(nrmGecy2)) for i in nrmGecy2]

    # plt.plot(nrmGecx1, nrmGecy1, color='black')
    # plt.plot(nrmGecx2, nrmGecy2, color='black')
    # plt.yscale('log')

    # plt.show()

def wghPrd(factors, weights):
    
    product = 1
    for i in range(len(factors)): 
        product *= factors[i]**weights[i]
    
    return product

def plotKcrs(met): 

    temperature_range = range(10, 600, 10)
    for obj in met.trgRcns:
            energies = [obj.calSimKcs(0, temp)[0] for temp in temperature_range]
        # if energies[-1] > 3000000: 
            plt.plot(temperature_range, energies, label=obj._id)

            energies = [obj.calSimKcs(0, temp)[1] for temp in temperature_range]
        # if energies[-1] > 3000000: 
            plt.plot(temperature_range, energies, label=obj._id)


            plt.yscale('log')
            plt.xlabel('Temperature')
            plt.ylabel('Energy')
            plt.title('Energy vs Temperature')
            plt.legend(ncol=2)
            plt.grid(True)
            plt.show()

def plotDstsHist(dsts, thrPer, thrVal):

    bins = 100
    binStp = (max(dsts)-min(dsts))/bins
    dsts1 = []
    dsts2 = []
    for i in dsts:
        if i < thrVal: dsts1.append(i)
        else: dsts2.append(i)
    plt.rcParams.update({'font.size': 11})

    plt.figure(figsize=(7,6))
    plt.hist(dsts1, bins=round((max(dsts1)-min(dsts1))/binStp), edgecolor='black', color='green')
    if thrPer < 100: 
        plt.hist(dsts2, bins=round((max(dsts2)-min(dsts2))/binStp), edgecolor='black')
    plt.axvline(thrVal, color='red', linestyle='dashed', linewidth=2, label=f'{thrPer} percentil at {round(thrVal)}')

    plt.xlabel(f'Sampled and simulated flux distributions euclidian distances')
    plt.ylabel('Occurences')
    plt.legend()
    plt.subplots_adjust(left=0.08, right=0.98, top=0.98, bottom=0.08)
    plt.show()

def avgDevAvgDst(smp):

    n = len(smp)
    mean = sum([entry[1] for entry in smp])/n
    
    return sum([abs(entry[1]-mean) for entry in smp])/n

def plotAvgDevAvgDstsHist(avgDevAvgDsts, nrm=True):

    if nrm:
        mu, std = norm.fit(avgDevAvgDsts)  
        x = np.linspace(min(avgDevAvgDsts), max(avgDevAvgDsts), 100) 
        p = norm.pdf(x, mu, std)
        plt.plot(x, p, 'k', linewidth=2)
        plt.axvline(mu, color='red', linestyle='solid', linewidth=2, label=f'Mean at {round(mu, 3)}')
    plt.rcParams.update({'font.size': 11})

    plt.figure(figsize=(7,6))
    plt.hist(avgDevAvgDsts, bins=100, edgecolor='black')#, density= True)
    plt.xlabel(f'Average absolute deviation to the average distance')
    plt.ylabel('Occurences')
    plt.subplots_adjust(left=0.1, right=0.98, top=0.98, bottom=0.08)
    plt.show()


def calRefs0(smps):

    cnc0 = []
    kcr0 = []
    kcf0 = []

    for smp in smps:
        cnc0.append(smp[0][2])
        kcr0.append(smp[0][3])
        kcf0.append(smp[0][4])

    refCnc0 = [sum(x) / len(cnc0) for x in zip(*cnc0)]
    refKcr0 = [sum(x) / len(kcr0) for x in zip(*kcr0)]
    refKcf0 = [sum(x) / len(kcf0) for x in zip(*kcf0)]
    refKin0 = [x + y for x, y in zip(refKcr0, refKcf0)]
    print(refCnc0)
    print(refKin0)

    return refCnc0, refKin0

def cncDevT(smp, refOsm0, h2oCnc):

    return [abs(-1+(sum(smpT[2])-h2oCnc)/refOsm0) for smpT in smp]

def avg(lst):

    return [sum(x) / len(lst) for x in zip(*lst)]

def plotCncDevs(tmps, avgCncDevTs, refOsm0=None, n=None):
    plt.rcParams.update({'font.size': 11})

    fig, ax = plt.subplots(figsize=(7, 6))

    ax.set_xlabel('Temperature (K)')
    ax.set_ylabel('$\overline{\Delta Osmolarity}$ (mOsm)')
    ax.set_xlim(-10, 810)

    ax_ = ax.twiny()
    ax_.set_xlabel('Temperature (ºC)') 
    ax_.set_xlim(-283.15, 536.85)

    ax.xaxis.set_major_locator(AutoLocator())
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax_.xaxis.set_major_locator(AutoLocator())
    ax_.xaxis.set_minor_locator(AutoMinorLocator())
    ax.xaxis.grid(which='both', linestyle='--', linewidth=0.5)


    avgCncDev = sum(avgCncDevTs)/len(avgCncDevTs)
    ax.axhline(y=avgCncDev, color='red', linestyle='solid', linewidth=2, label=f'{round(avgCncDev, 3)} mOsm average deviation')
    ax.plot(tmps, avgCncDevTs, label=f'Deviation from the {round(refOsm0, 3)} mOsm reference osmolarity')

    ax.legend()
    fig.tight_layout()

    plt.subplots_adjust(left=0.11, right=0.98, top=0.92, bottom=0.08)

    plt.show()

# fig, ax1 = plt.subplots()

# ax1.set_xlabel('Temperature (K)')
# ax1.set_ylabel('Normalized stress', color='black')
# ax1.plot(tmp[1:], glbKinStrAvg, color='tab:blue')
# ax1.set_xlim(-10, 810)

# ax2 = ax1.twinx() 
# ax2.set_ylabel('Equilibrium Constant (kJ)', color='black') 
# ax2.plot(gecx1, gecy1, color='tab:red', label='ACONTb')
# ax2.plot(gecx2, gecy2, color='tab:green', label='GAPD')
# ax2.set_yscale('log')
# ax2.set_ylim(0.001, 1000)
# ax2.legend(loc='lower left')

# ax3 = ax1.twiny()
# ax3.set_xlabel('Temperature (ºC)') 
# ax3.set_xlim(-283.15, 536.85)

# ax1.xaxis.set_major_locator(AutoLocator())
# ax1.xaxis.set_minor_locator(AutoMinorLocator())
# ax3.xaxis.set_major_locator(AutoLocator())
# ax3.xaxis.set_minor_locator(AutoMinorLocator())
# ax1.xaxis.grid(which='both', linestyle='--', linewidth=0.5)

# fig.suptitle(f'Stress analysis for {folder_path}')
# fig.tight_layout()  # otherwise the right y-label is slightly clipped
# plt.show()
