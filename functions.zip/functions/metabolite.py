class Metabolite:
    
    def __init__(self, model, _nm, _id, cmp):
        
        self.model = model
        self._nm = _nm
        self._id =  _id
        self.cmp = cmp
        
        self.cnc = None
        self.simCncs = [None for _ in range(model.nSims)]

    def __str__(self): return self._id

    def getId(self): return self._id
        
    def getCmp(self): return self.cmp

    def getCnc(self): return self.cnc 

    def getSimCnc(self, sim): return self.simCncs[sim]
    
    def setCnc(self, cnc, dflCnc = 0.2):

        if cnc != cnc: self.cnc = dflCnc
        else: self.cnc = cnc

    def setSimCncs(self):

        self.simCncs = [self.cnc for _ in self.simCncs]

    def nosSimCncs(self, noise):

        self.simCncs = [cnc*dv if cnc*dv > 0 else 0 for cnc, dv in zip(self.simCncs, noise)]

    def chgCnc(self, sim):

        self.cnc = self.simCncs[sim]

    def repSimCncs(self, sim):

        self.simCncs = [self.simCncs[sim] for _ in self.simCncs]


class H2o(Metabolite):

    def __init__(self, model, _nm, _id, cmp):

        super().__init__(model, _nm, _id, cmp)

    def setCnc(self, cnc):

        self.cnc = cnc
        self.model.setH2ocCnc(cnc)

    def nosSimCncs(self, noise):

        pass
